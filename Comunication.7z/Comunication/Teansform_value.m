function [C]=Teansform_value(A,B)
for i=1:1:size(A,1)
    for j=1:1:size(A,2)
        if A(i,j)==0&&B(i,j)~=0
            A(i,j)=B(i,j);
        end
    end
end
C=A;