%This code is used to present a simple broadcast comunicational way 
%(high-distributed Mult-ihop) used in our paper: "Broadcast your 
%weaknesses: cooperative active pose-graph SLAM for multiple robots".

% Copyright (C) 2019 by Yongbo Chen
%% Clear environment
clc
clear
close all
warning off
%% Initialization
Rang_comunication=3; %Comunication range 3m
N_uav=5; %UAV number
UAV{1}.poses=[0,0];%Robot poses
UAV{2}.poses=[3,4];
UAV{3}.poses=[3,2];
UAV{4}.poses=[1,4];
UAV{5}.poses=[5,2];
for i=1:1:N_uav%5 uavs
    UAV{i}.in_data=zeros(N_uav,N_uav+1);%Recived messages
    UAV{i}.out_data=zeros(N_uav,N_uav+1);%Broadcast message
    UAV{i}.in=0;%Something to recieve
    UAV{i}.out=0;%Something to broadcast
    UAV{i}.item=0;%Broadcast times
    plot(UAV{i}.poses(1),UAV{i}.poses(2),'*');%Plot robot
    text(UAV{i}.poses(1),UAV{i}.poses(2),['robot',num2str(i)]);%Plot robot
    hold on;
    H{i}=[];%Initialize useful message directions
end
axis([-5 10 -5 10]);%Axis limitation
%% Input the robot has something to publish
I = input('Enter a robot which has the weakness to broadcast:');
if isnan(I) || fix(I) ~= I 
    disp('Please enter an integer');
end
if I>N_uav
    fprintf('Please input a integer between 1 and %i\n', N_uav);
    I = input('Enter a robot which has the weakness to broadcast:');
    if isnan(I) || fix(I) ~= I 
      disp('Please enter an integer');
    end
end
UAV{I}.in=1;
UAV{I}.out=1;
UAV{I}.out_data(I,N_uav+1)=1;
%% Comunication and bidding framework
total_generation=5;%Time step
for k=1:1:total_generation%Comunication time step limitation
    for i=1:1:N_uav%For every robot (Simulate the parallel state of every robot)
        %% Broadcast
        if UAV{i}.out==1&&UAV{i}.item<1&&UAV{i}.in==1%the robot has something to broadcast
            hcircle{i}=plot_comunication(UAV{i},Rang_comunication);%Broadcast range
            UAV{i}.item=UAV{i}.item+1;%count
        end
        %% Message transformation
        for j=1:1:N_uav%When a robot broadcast, the action of the other robot
            if i~=j%Broadcast to other robots
                if norm(UAV{i}.poses-UAV{j}.poses)<=Rang_comunication&&UAV{i}.out==1&&~isempty(find(UAV{i}.out_data-UAV{j}.in_data>0))
                    %% If a robot locates inside the comunication range and the recieved
                    % message is different from its orange saved message
                    H{j}=arrow(UAV{i}.poses,UAV{j}.poses);%Plot the transform direction of the updated messages
                    UAV{j}.in_data=Teansform_value(UAV{j}.in_data,UAV{i}.out_data);
                    UAV{j}.out_data=Teansform_value(UAV{j}.out_data,UAV{i}.out_data);%Message update
                    UAV{j}.in=1;
                    [order]=find(UAV{j}.in_data(:,end)==1);%Find out which robot is the original broadcaster
                    dis=norm(UAV{order}.poses-UAV{j}.poses);%Compute cost to deal with the weakness for bidding
                    UAV{j}.out_data(order,j)=dis;%Update the cost of the reciever (It is more complicate in the complete framework. This is just a simple demo.)
                    UAV{j}.in_data=UAV{j}.out_data;
                    UAV{j}.out=1;%Want to broadcast something
                else
                end
            end
        end 
        pause(0.2);%It is not a time step. It is used to see array more clear.
        %% Delete message and broadcast range in this time step and re-inilization
        for j=1:1:N_uav
            delete(H{j});%message array
            H{j}=[];
        end
        if UAV{i}.item==1
            UAV{i}.out=0;
            UAV{i}.item=0;
            UAV{i}.in=0;
            delete(hcircle{i});%broadcast range
        end
    end
end
%% Bidding 
[all]=find(UAV{I}.in_data(I,1:N_uav)~=0);
[v,o]=min(UAV{I}.in_data(I,all));
%% Result output
if isempty(all(o))
    fprintf('No robot wins the bidding.\n The broadcast robot is too far away from other robots.', all(o));
else
    fprintf('Bidding result is that the %i-th robot wins the bidding.', all(o));
end