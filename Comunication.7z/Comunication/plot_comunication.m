function [hcircle]=plot_comunication(UAV,Rang_comunication)
t = 0:0.5:10; 
totalFrame = max(size(t));
for i=2:1:totalFrame
    r0 = Rang_comunication/totalFrame;  % R?????,???t????
    R  = 0:r0:Rang_comunication;            % ???40~280
    hcircle=circle(R(i),UAV.poses(1),UAV.poses(2));
    hold on
    pause(0.01);%??0.01s
    if i~=totalFrame
        delete(hcircle);
    else
    end
end
end