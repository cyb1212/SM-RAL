%This code is used to present a simple broadcast comunicational way.

% Copyright (C) 2019 by Yongbo Chen
%% Clear environment
clc
clear
close all
warning off
%% Scene
Rang_comunication=3;
UAV{1}.poses=[0,0];
UAV{2}.poses=[3,4];
UAV{3}.poses=[3,2];
UAV{4}.poses=[1,4];
UAV{5}.poses=[5,2];
for i=1:1:5%5 uavs
    plot(UAV{i}.poses(1),UAV{i}.poses(2),'*');
    
    hold on
end
t = 0:0.5:10; 
totalFrame = max(size(t));
axis([-5 10 -5 10]);
for i=2:1:totalFrame
    r0 = Rang_comunication/totalFrame;  % R?????,???t????
    R  = 0:r0:Rang_comunication;            % ???40~280
    for j=1:1:5%circle_test
        hcircle{j}=circle(R(i),UAV{j}.poses(1),UAV{j}.poses(2));
        hold on
    end
    pause(0.01);%??0.01s
    if i~=totalFrame
        for j=1:1:5
            delete(hcircle{j});
        end
    else
    end
end